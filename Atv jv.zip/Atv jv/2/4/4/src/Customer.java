public class Customer {
    protected int id;
    protected String name;
    protected int discount;

    Customer(int id, String name, int discount) {
        this.discount = discount;
        this.name = name;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public String toString() {
        return "Customer[name = " + this.id + ", discount = " + this.discount + "%]";
    }
}