public class Invoice {
    private int id;
    private Customer customer;
    private double ammount;

    Invoice(int id, Customer customer, double ammount) {
        this.id = id;
        this.customer = customer;
        this.ammount = ammount;
    }

    public int getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public double getAmmount() {
        return ammount;
    }

    public void setAmmount(double ammount) {
        this.ammount = ammount;
    }

    public int getCustomerId() {
        return this.customer.id;
    }

    public String getCustomerName() {
        return this.customer.name;
    }

    public int getCustomerDiscount() {
        return this.customer.discount;
    }

    public double getAmmountAfterDiscount() {
        return (this.ammount - ((this.customer.discount * this.ammount) / 100));
    }

    public String toString() {
        return "Invoice[id = " + this.id + ", " + this.customer.toString() + ", ammount = " + this.ammount + "]";
    }
}
