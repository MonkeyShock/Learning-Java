public class TestMyTriangle {
    public static void main(String[] args) {
        // Test constructor with coordinates
        MyTriangle triangle1 = new MyTriangle(0, 0, 3, 0, 0, 4);
        System.out.println(triangle1); // Expected: MyTriangle[v1=(0,0),v2=(3,0),v3=(0,4)]
        System.out.println("Perimeter: " + triangle1.getPerimeter()); // Expected: 12.0
        triangle1.printType(); // Expected: scalene

        // Test constructor with MyPoint instances
        MyPoint p1 = new MyPoint(1, 1);
        MyPoint p2 = new MyPoint(2, 2);
        MyPoint p3 = new MyPoint(3, 3);
        MyTriangle triangle2 = new MyTriangle(p1, p2, p3);
        System.out.println(triangle2); // Expected: MyTriangle[v1=(1,1),v2=(2,2),v3=(3,3)]
        System.out.println("Perimeter: " + triangle2.getPerimeter()); // Perimeter calculation
        triangle2.printType(); // Expected: isosceles (if distances are calculated as equal)

        // Additional test cases
        MyTriangle triangle3 = new MyTriangle(new MyPoint(0, 0), new MyPoint(4, 0), new MyPoint(2, 3));
        System.out.println(triangle3); // Expected: MyTriangle[v1=(0,0),v2=(4,0),v3=(2,3)]
        System.out.println("Perimeter: " + triangle3.getPerimeter()); // Perimeter calculation
        triangle3.printType(); // Expected: scalene

        MyTriangle triangle4 = new MyTriangle(new MyPoint(0, 0), new MyPoint(0, 3), new MyPoint(3, 0));
        System.out.println(triangle4); // Expected: MyTriangle[v1=(0,0),v2=(0,3),v3=(3,0)]
        System.out.println("Perimeter: " + triangle4.getPerimeter()); // Perimeter calculation
        triangle4.printType(); // Expected: isosceles
    }
}
