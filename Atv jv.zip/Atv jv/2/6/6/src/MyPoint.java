
public class MyPoint {
    private int x;
    private int y;

    MyPoint() {
        this.x = 0;
        this.y = 0;
    }

    MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int[] getXY() {
        int[] XY = new int[2];
        XY[0] = this.x;
        XY[1] = this.y;
        return XY;
    }

    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String toString() {
        return "(" + this.x + "," + this.y + ")";
    }

    public double distance(int x, int y) {
        return Math.sqrt((Math.pow(2, x - this.x) + Math.pow(2, y - this.y)));
    }

    public double distance(MyPoint another) {
        return Math.sqrt((Math.pow(2, another.x - this.x) + Math.pow(2, another.y - this.y)));
    }

    public double distance() {
        return Math.sqrt((Math.pow(2, this.x) + Math.pow(2, this.y)));
    }
}