public class TestMyRectangle {
    public static void main(String[] args) {
        // Test constructor with coordinates
        MyRectangle rect1 = new MyRectangle(1, 4, 5, 1);
        System.out.println(rect1); // Expected: MyRectangle[topLeft=(1,4),bottomRight=(5,1)]
        System.out.println("Width: " + rect1.getWidth()); // Expected: 4
        System.out.println("Height: " + rect1.getHeight()); // Expected: 3
        System.out.println("Area: " + rect1.getArea()); // Expected: 12
        System.out.println("Perimeter: " + rect1.getPerimeter()); // Expected: 14

        // Test constructor with MyPoint instances
        MyPoint p1 = new MyPoint(2, 6);
        MyPoint p2 = new MyPoint(7, 3);
        MyRectangle rect2 = new MyRectangle(p1, p2);
        System.out.println(rect2); // Expected: MyRectangle[topLeft=(2,6),bottomRight=(7,3)]
        System.out.println("Width: " + rect2.getWidth()); // Expected: 5
        System.out.println("Height: " + rect2.getHeight()); // Expected: 3
        System.out.println("Area: " + rect2.getArea()); // Expected: 15
        System.out.println("Perimeter: " + rect2.getPerimeter()); // Expected: 16

        // Test setters and getters
        MyRectangle rect3 = new MyRectangle(new MyPoint(0, 0), new MyPoint(3, 3));
        rect3.setTopLeft(new MyPoint(1, 1));
        rect3.setBottomRight(new MyPoint(4, 4));
        System.out.println(rect3); // Expected: MyRectangle[topLeft=(1,1),bottomRight=(4,4)]
        System.out.println("Width: " + rect3.getWidth()); // Expected: 3
        System.out.println("Height: " + rect3.getHeight()); // Expected: 3
        System.out.println("Area: " + rect3.getArea()); // Expected: 9
        System.out.println("Perimeter: " + rect3.getPerimeter()); // Expected: 12
    }
}
