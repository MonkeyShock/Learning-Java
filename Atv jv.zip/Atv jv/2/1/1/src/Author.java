public class Author {
    protected String name;
    protected String email;
    protected char gender;

    Author(String name, String email, char gender) {
        this.gender = gender;
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public char getGender() {
        return gender;
    }

    public String toString() {
        return "Author[name = " + this.name + ", email = " + this.email + ", gender = " + this.gender;
    }

}