public class TestMyLine {
    public static void main(String[] args) {
        // Create MyPoint instances
        MyPoint p1 = new MyPoint(1, 2);
        MyPoint p2 = new MyPoint(4, 6);

        // Create MyLine instance using points
        MyLine line1 = new MyLine(p1, p2);
        System.out.println(line1); // Expected: MyLine[begin=(1, 2), end=(4, 6)]

        // Create MyLine instance using coordinates
        MyLine line2 = new MyLine(1, 2, 4, 6);
        System.out.println(line2); // Expected: MyLine[begin=(1, 2), end=(4, 6)]

        // Test getter and setter methods
        line1.setBegin(new MyPoint(0, 0));
        line1.setEnd(new MyPoint(3, 4));
        System.out.println(line1); // Expected: MyLine[begin=(0, 0), end=(3, 4)]

        // Test length calculation
        System.out.println("Length of line1: " + line1.getLength()); // Expected: 5.0

        // Test individual coordinate getters and setters
        line1.setBeginX(2);
        line1.setBeginY(2);
        line1.setEndX(5);
        line1.setEndY(6);
        System.out.println(line1); // Expected: MyLine[begin=(2, 2), end=(5, 6)]

        // Test array getters and setters
        line1.setBeginXY(1, 1);
        line1.setEndXY(7, 8);
        System.out.println(line1); // Expected: MyLine[begin=(1, 1), end=(7, 8)]
    }
}
