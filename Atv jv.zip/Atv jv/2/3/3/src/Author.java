public class Author {
    protected String name;
    protected String email;

    Author(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String toString() {

        return "Author[name = " + this.name + ", email = " + this.email + "]";
    }
}
