public class TestMain {
    public static void main(String[] args) {
        // Criação de um cliente
        Customer customer1 = new Customer(2, "John Doe", 'm');

        // Criação de uma conta com saldo inicial
        Account account1 = new Account(1, customer1, 100.0);
        System.out.println(account1); // Saída esperada: Customer: John Doe, balance = $100.0

        // Depósito de dinheiro
        account1 = account1.deposit(50.0);
        System.out.println(account1); // Saída esperada: Customer: John Doe, balance = $150.0

        // Saque de dinheiro
        account1 = account1.withdraw(30.0);
        System.out.println(account1); // Saída esperada: Customer: John Doe, balance = $120.0

        // Tentativa de saque que excede o saldo
        account1 = account1.withdraw(200.0);
        System.out.println(account1);
    }
}