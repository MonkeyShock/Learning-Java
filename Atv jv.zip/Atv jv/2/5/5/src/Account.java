public class Account {
    private int id;
    private Customer customer;
    private double balance;

    Account(int id, Customer customer, double balance) {
        this.balance = balance;
        this.id = id;
        this.customer = customer;
    }

    Account(int id, Customer customer) {
        this.balance = 0.0;
        this.id = id;
        this.customer = customer;
    }

    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String toString() {
        return this.customer + "balance = $" + this.balance;
    }

    public String getCustomerName() {
        return this.customer.getName();
    }

    public Account deposit(double amount) {
        Account p1 = new Account(this.id, this.customer, this.balance + amount);
        return p1;
    }

    public Account withdraw(double amount) {
        if (this.balance >= amount) {
            Account p1 = new Account(this.id, this.customer, this.balance - amount);
            return p1;
        } else
            return this;

    }
}
