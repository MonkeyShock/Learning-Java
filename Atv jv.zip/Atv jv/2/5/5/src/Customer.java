public class Customer {
    private int id;
    private String name;
    private char gender;

    Customer(int id, String name, char gender) {
        this.gender = gender;
        this.id = id;
        this.name = name;
    }

    public char getGender() {
        return gender;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return this.name + "(" + this.id + ")";
    }
}