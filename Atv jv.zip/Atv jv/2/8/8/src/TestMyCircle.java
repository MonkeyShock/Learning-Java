public class TestMyCircle {
    public static void main(String[] args) {
        // Test default constructor
        MyCircle circle1 = new MyCircle();
        System.out.println(circle1); // Expected: MyCircle[radius=1,center=(0,0)]
        System.out.println("Area: " + circle1.getArea()); // Expected: Area: 3.141592653589793
        System.out.println("Circumference: " + circle1.getCircumference()); // Expected: Circumference:
                                                                            // 6.283185307179586

        // Test constructor with (x, y, radius)
        MyCircle circle2 = new MyCircle(3, 4, 5);
        System.out.println(circle2); // Expected: MyCircle[radius=5,center=(3,4)]
        System.out.println("Distance from circle1: " + circle1.distance(circle2)); // Distance between (0,0) and (3,4)

        // Test constructor with (MyPoint, radius)
        MyPoint point = new MyPoint(1, 2);
        MyCircle circle3 = new MyCircle(point, 7);
        System.out.println(circle3); // Expected: MyCircle[radius=7,center=(1,2)]

        // Test setters and getters
        circle3.setRadius(10);
        System.out.println(circle3.getRadius()); // Expected: 10
        circle3.setCenter(new MyPoint(9, 9));
        System.out.println(circle3.getCenter()); // Expected: (9,9)

        // Test individual center coordinate setters and getters
        circle3.setCenterX(5);
        circle3.setCenterY(5);
        System.out.println(circle3.getCenterX()); // Expected: 5
        System.out.println(circle3.getCenterY()); // Expected: 5
    }
}
