public class Book {
    private String name;
    private Author[] authors;
    private double price;
    private int qty;

    Book(String name, Author[] authors, double price) {
        this.name = name;
        this.authors = authors;
        this.price = price;
    }

    Book(String name, Author[] authors, double price, int qty) {
        this.name = name;
        this.authors = authors;
        this.price = price;
        this.qty = qty;
    }

    public String getName() {
        return name;
    }

    public Author[] getAuthor() {
        return authors;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String toString() {
        StringBuilder authorsNames = new StringBuilder();
        for (Author author : authors) {
            authorsNames.append(author.getName()).append(", ");
        }
        if (authorsNames.length() > 0) {
            authorsNames.setLength(authorsNames.length() - 2); // Remove the trailing comma and space
        }
        return "Book[name=" + name + ", authors={" + authorsNames + "}, price=" + price + ", qty=" + qty + "]";
    }

    public String getAuthorNames() {
        StringBuilder authorNames = new StringBuilder();
        for (Author author : authors) {
            authorNames.append(author.getName()).append(", ");
        }
        if (authorNames.length() > 0) {
            authorNames.setLength(authorNames.length() - 2); // Remove the trailing comma and space
        }
        return authorNames.toString();
    }
}
