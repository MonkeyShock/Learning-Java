import java.util.Date;

public class TestDiscountSystem {
    public static void main(String[] args) {
        Customer customer1 = new Customer("John Doe");
        customer1.setMember(true);
        customer1.setMemberType("Premium");

        Visit visit1 = new Visit(customer1, new Date());
        visit1.setServiceExpense(100);
        visit1.setProductExpense(50);

        System.out.println(customer1);
        System.out.println(visit1);
        System.out.println("Total Expense: " + visit1.getTotalExpense());

        Customer customer2 = new Customer("Jane Doe");
        customer2.setMember(true);
        customer2.setMemberType("Gold");

        Visit visit2 = new Visit(customer2, new Date());
        visit2.setServiceExpense(80);
        visit2.setProductExpense(30);

        System.out.println(customer2);
        System.out.println(visit2);
        System.out.println("Total Expense: " + visit2.getTotalExpense());

        Customer customer3 = new Customer("Alice");
        customer3.setMember(false);

        Visit visit3 = new Visit(customer3, new Date());
        visit3.setServiceExpense(120);
        visit3.setProductExpense(70);

        System.out.println(customer3);
        System.out.println(visit3);
        System.out.println("Total Expense: " + visit3.getTotalExpense());
    }
}
