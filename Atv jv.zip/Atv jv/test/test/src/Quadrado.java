public class Quadrado extends Forma {
    Quadrado(double a) {
        super(a, a);
    }

    public double getLado() {

        return super.getAltura();
    }

    @Override
    public double getArea() {
        return super.getArea();
    }

    @Override
    public String toString() {
        return "Quadrado: " + super.getBase();
    }
}
