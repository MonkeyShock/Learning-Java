public class Retangulo extends Forma {
    Retangulo(double a, double b) {
        super(b, a);
    }

    @Override
    public double getAltura() {

        return super.getAltura();
    }

    @Override
    public double getBase() {

        return super.getBase();
    }

    @Override
    public double getArea() {

        return super.getArea();
    }

    @Override
    public void setAltura(double a) {
        // TODO Auto-generated method stub
        super.setAltura(a);
    }

    @Override
    public void setBase(double b) {
        // TODO Auto-generated method stub
        super.setBase(b);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
