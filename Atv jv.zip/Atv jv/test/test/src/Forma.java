abstract class Forma {
    private double b;
    private double a;

    Forma(double b, double a) {
        this.a = a;
        this.b = b;
    }

    public double getAltura() {
        return a;
    }

    public double getBase() {
        return b;
    }

    public void setAltura(double a) {
        this.a = a;
    }

    public void setBase(double b) {
        this.b = b;
    }

    public double getArea() {
        return (this.a * this.b);
    }

    @Override
    public String toString() {
        return "Forma: " + "Altura = " + this.a + " Base = " + this.b;
    }
}
