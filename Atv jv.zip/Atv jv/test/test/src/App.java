public class App {
    public static void main(String[] args) throws Exception {
        Forma R = new Retangulo(12, 4);
        Forma Q = new Quadrado(2);
        double AreR = R.getArea();
        try {
            double AreQ = Q.getAltura();
        } catch (Exception e) {
            System.err.println("Não tem como pegar a altura");
        }
        System.out.println("Area = " + AreR + ", Area Q = " + Q.getArea());
    }
}
