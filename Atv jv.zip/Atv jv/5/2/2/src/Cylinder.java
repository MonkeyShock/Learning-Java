public class Cylinder {
    private Circle base; // Base circle, an instance of Circle class
    private double height;

    // Constructor with default color, radius and height
    public Cylinder() {
        base = new Circle(); // Call the constructor to construct the Circle
        height = 1.0;
    }

    public Cylinder(Circle base, double height) {
        this.base = base;
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setBase(Circle base) {
        this.base = base;
    }

    public Circle getBase() {
        return base;
    }

    public double getArea() {
        return ((2 * (Math.PI) * this.base.getRadius() * this.height) + (this.base.getArea()));
    }

    @Override
    public String toString() {
        return "Cylinder[" + this.base.toString() + ", height = " + this.height;
    }
}