public class Main {

    public static void main(String[] args) {
        // Create a Circle with specific radius and color
        Circle baseCircle = new Circle(3.0, "blue");

        // Create a Cylinder with the custom Circle and height
        Cylinder cylinder1 = new Cylinder(baseCircle, 5.0);

        // Print the Cylinder details
        System.out.println(cylinder1); // Output: Cylinder[Circle[radius = 3.0, color = blue], height = 5.0]

        // Access and modify properties
        System.out.println("\nBase Circle details before modification:");
        System.out.println(cylinder1.getBase()); // Output: Circle[radius = 3.0, color = blue]

        cylinder1.getBase().setColor("green"); // Modify color of the base circle through Cylinder

        System.out.println("\nBase Circle details after modification:");
        System.out.println(cylinder1.getBase()); // Output: Circle[radius = 3.0, color = green] (Color changed)

        System.out.println("\nCylinder details after modification:");
        System.out.println(cylinder1); // Output: Cylinder[Circle[radius = 3.0, color = green], height = 5.0] (Color
                                       // change reflected)
        double baseArea = cylinder1.getBase().getArea();
        double lateralArea = 2 * Math.PI * cylinder1.getBase().getRadius() * cylinder1.getHeight();
        double totalArea = baseArea + lateralArea;
        System.out.println("Total area: " + totalArea);
    }
}
