public class Main {

    public static void main(String[] args) {
        // Create a MovablePoint with initial position and speed
        MovablePoint point1 = new MovablePoint(5.0f, 3.0f, -2.0f, -1.0f);

        System.out.println("Initial Point: " + point1); // Output: Initial Point: (5.0, 3.0), speed = 2.0, 1.0

        // Move the point and print the new position
        point1.move();
        System.out.println("After move: " + point1);

        // Access and modify speed
        point1.setxSpeed(3.0f);
        point1.setySpeed(-0.5f);

        System.out.println("Updated speed: " + point1.toString()); // Output: Updated speed: (7.0, 4.0), speed = 3.0,
                                                                   // -0.5

        // Get speed as an array
        float[] speed = point1.getSpeed();
        System.out.print("Speed in array: [");
        for (float value : speed) {
            System.out.print(value + ", ");
        }
        System.out.println("]"); // Output: Speed in array: [3.0, -0.5, ]

        // Create MovablePoint with default speed (0, 0)
        MovablePoint point2 = new MovablePoint();
        System.out.println("Point with default speed: " + point2); // Output: Point with default speed: (0.0, 0.0),
                                                                   // speed = 0.0, 0.0
    }
}
