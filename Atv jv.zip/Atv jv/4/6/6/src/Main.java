public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("Kitty");
        Dog dog1 = new Dog("Buddy");
        Dog dog2 = new Dog("Max");

        System.out.println(cat.toString());
        cat.greets();

        System.out.println(dog1.toString());
        dog1.greets();

        dog1.greets(dog2);
    }
}