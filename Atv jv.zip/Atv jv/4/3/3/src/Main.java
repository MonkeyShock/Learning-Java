public class Main {

    public static void main(String[] args) {
        // Create a 2D point
        Point2D point2D = new Point2D(3.5f, 7.2f);
        System.out.println("2D Point: " + point2D); // Output: 2D Point: (3.5, 7.2)

        // Create a 3D point
        Point3D point3D = new Point3D(1.0f, 4.5f, -2.3f);
        System.out.println("3D Point: " + point3D); // Output: 3D Point: (1.0, 4.5, -2.3)

        // Access and modify coordinates
        point2D.setX(5.0f);
        point3D.setZ(5.0f);

        System.out.println("Modified 2D Point: " + point2D); // Output: Modified 2D Point: (5.0, 7.2)
        System.out.println("Modified 3D Point: " + point3D); // Output: Modified 3D Point: (1.0, 4.5, 0.0)

        // Get coordinates as arrays
        float[] coords2D = point2D.getXY();
        float[] coords3D = point3D.getXYZ();

        System.out.print("2D Coordinates: [");
        for (float coord : coords2D) {
            System.out.print(coord + ", ");
        }
        System.out.println("]"); // Output: 2D Coordinates: [5.0, 7.2, ]

        System.out.print("3D Coordinates: [");
        for (float coord : coords3D) {
            System.out.print(coord + ", ");
        }
        System.out.println("]"); // Output: 3D Coordinates: [1.0, 4.5, 0.0, ]
    }
}
