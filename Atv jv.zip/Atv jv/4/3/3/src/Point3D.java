public class Point3D extends Point2D {
    private float z;

    Point3D(float x, float y, float z) {
        super(x, y);
        this.z = z;
    }

    Point3D() {
        super();
        this.z = 0.0f;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    public void setXYZ(float x, float y, float z) {
        super.setXY(x, y);
        setZ(z);
    }

    public float[] getXYZ() {
        float[] XYZ = new float[3];
        float[] ts = new float[2];
        ts = super.getXY();
        XYZ[0] = ts[0];
        XYZ[1] = ts[1];
        XYZ[2] = getZ();
        return XYZ;
    }

    @Override
    public String toString() {
        return super.toString().replace(")", ", ") + getZ() + ")";
    }

}
