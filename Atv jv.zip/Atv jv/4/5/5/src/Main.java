public class Main {

    public static void main(String[] args) {
        // Create shapes with different constructors
        Shape shape1 = new Shape(); // Default red, filled
        Circle circle1 = new Circle(3.0, "blue", false); // Blue, not filled, radius 3.0
        Rectangle rectangle1 = new Rectangle(5.0, 2.0); // Default color/filled, width 5.0, length 2.0
        Square square1 = new Square(4.0, "green", true); // Green, filled, side 4.0 (calls Rectangle constructor)

        // Print shapes
        System.out.println(shape1); // Output: Shape[color = red, filled = true]
        System.out.println(circle1); // Output: Circle[Shape[color = blue, filled = false], radius = 3.0]
        System.out.println(rectangle1); // Output: Rectangle[Shape[color = red, filled = true], width = 5.0, length =
                                        // 2.0]
        System.out.println(square1); // Output: Square[Rectangle[Shape[color = green, filled = true], width = 4.0,
                                     // length = 4.0]]

        // Set and get properties
        shape1.setColor("yellow");
        rectangle1.setWidth(7.0);
        square1.setSide(6.0);

        System.out.println("\nAfter modifications:");
        System.out.println(shape1); // Output: Shape[color = yellow, filled = true]
        System.out.println(rectangle1); // Output: Rectangle[Shape[color = red, filled = true], width = 7.0, length =
                                        // 2.0] (length remains unchanged)
        System.out.println(square1); // Output: Square[Rectangle[Shape[color = green, filled = true], width = 6.0,
                                     // length = 6.0]] (both width and length become 6.0)

        // Calculate areas
        System.out.println("\nAreas:");
        System.out.println("Circle area: " + circle1.getArea()); // Output: Circle area: 28.274333882308138 (assuming
                                                                 // Math.PI is used)
        System.out.println("Rectangle area: " + rectangle1.getArea()); // Output: Rectangle area: 14.0 (7.0 * 2.0)
        System.out.println("Square area: " + square1.getArea()); // Output: Square area: 36.0 (6.0 * 6.0)
    }
}
