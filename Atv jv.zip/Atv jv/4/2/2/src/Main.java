public class Main {

    public static void main(String[] args) {

        // Create a Student object
        Student student1 = new Student("John Doe", "123 Main St", "Computer Science", 3, 10000.00);

        // Create a Staff object
        Staff staff1 = new Staff("Jane Smith", "456 Elm St", "Engineering School", 80000.00);

        // Print information about the Student
        System.out.println(student1);

        // Update the student's program
        student1.setProgram("Software Engineering");

        // Print information about the Student again (showing the updated program)
        System.out.println(student1);

        // Print information about the Staff
        System.out.println(staff1);
    }
}
