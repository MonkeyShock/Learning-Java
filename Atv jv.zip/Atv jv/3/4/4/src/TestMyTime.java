public class TestMyTime {
    public static void main(String[] args) {
        MyTime time = new MyTime(23, 59, 59);
        System.out.println("Initial time: " + time);

        System.out.println("Next second: " + time.nextSecond());
        System.out.println("Next minute: " + time.nextMinute());
        System.out.println("Next hour: " + time.nextHour());

        time.setTime(0, 0, 0);
        System.out.println("Time set to 00:00:00");

        System.out.println("Previous second: " + time.previousSecond());
        System.out.println("Previous minute: " + time.previousMinute());
        System.out.println("Previous hour: " + time.previousHour());

        try {
            time.setHour(25); // This should throw an exception
        } catch (IllegalArgumentException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            time.setMinute(60); // This should throw an exception
        } catch (IllegalArgumentException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            time.setSecond(60); // This should throw an exception
        } catch (IllegalArgumentException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
