public class Player {
    private String name;
    private int number;

    public Player(String name, int number) {
        this.name = name;
        this.number = number;
    }

    public void kick(Ball ball, double power, double angle) {
        // Implement kicking behavior based on power and angle
        // For simplicity, let's assume the ball's direction changes based on the kick
        // We'll update the ball's xDelta and yDelta based on the power and angle of the
        // kick
        double xDelta = power * Math.cos(Math.toRadians(angle));
        double yDelta = power * Math.sin(Math.toRadians(angle));
        ball.setxDelta(xDelta);
        ball.setyDelta(yDelta);
    }

    public String toString() {
        return String.format("Player %s (#%d)", name, number);
    }
}
