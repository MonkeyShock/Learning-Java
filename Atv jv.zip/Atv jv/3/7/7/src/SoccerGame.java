public class SoccerGame {
    public static void main(String[] args) {
        // Create a ball
        Ball ball = new Ball(0, 0, 0, 0);

        // Create two teams of players
        Player[] team1 = {
                new Player("Player1", 1),
                new Player("Player2", 2),
                new Player("Player3", 3)
        };

        Player[] team2 = {
                new Player("Player4", 4),
                new Player("Player5", 5),
                new Player("Player6", 6)
        };

        // Simulate game
        for (int i = 0; i < 10; i++) {
            // Randomly select a player to kick the ball
            Player kicker = (i % 2 == 0) ? team1[(int) (Math.random() * team1.length)]
                    : team2[(int) (Math.random() * team2.length)];

            // Simulate kicking the ball
            double power = Math.random() * 10; // Random power between 0 and 10
            double angle = Math.random() * 360; // Random angle between 0 and 360
            kicker.kick(ball, power, angle);

            // Simulate ball movement
            ball.move();

            // Print ball position
            System.out.println(ball);
        }
    }
}
