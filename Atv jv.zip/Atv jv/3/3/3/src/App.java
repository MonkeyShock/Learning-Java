import java.math.BigInteger;

public class App {
    public static void main(String[] args) throws Exception {
        BigInteger x = new BigInteger("11111111111111111111111111111111111111111111111111111111111111");
        BigInteger y = new BigInteger("22222222222222222222222222222222222222222222222222");
        System.out.println(x);
        System.out.println(y);
        System.out.println(x.add(y));
        System.out.println(x.multiply(y));
    }
}
