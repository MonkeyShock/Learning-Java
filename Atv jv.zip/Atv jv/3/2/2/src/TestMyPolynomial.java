public class TestMyPolynomial {
    public static void main(String[] args) {
        MyPolynomial p1 = new MyPolynomial(1.1, 2.2, 3.3);
        MyPolynomial p2 = new MyPolynomial(4.4, 5.5, 6.6, 7.7);

        System.out.println("Polynomial p1: " + p1);
        System.out.println("Polynomial p2: " + p2);

        System.out.println("Degree of p1: " + p1.getDegree());
        System.out.println("Degree of p2: " + p2.getDegree());

        double x = 2.0;
        System.out.println("p1 evaluated at " + x + " is: " + p1.evaluate(x));
        System.out.println("p2 evaluated at " + x + " is: " + p2.evaluate(x));

        MyPolynomial sum = p1.add(p2);
        System.out.println("Sum of p1 and p2: " + sum);

        MyPolynomial product = p1.multiply(p2);
        System.out.println("Product of p1 and p2: " + product);
    }
}
