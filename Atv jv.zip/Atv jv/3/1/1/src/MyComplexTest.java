public class MyComplexTest {
    public static void main(String[] args) {
        MyComplex num1 = new MyComplex(1.1, 2.2);
        MyComplex num2 = new MyComplex(3.3, 4.4);

        System.out.println("Number 1 is: " + num1);
        System.out.println(num1 + " is " + (num1.isReal() ? "" : "NOT ") + "a pure real number");
        System.out.println(num1 + " is " + (num1.isImaginary() ? "" : "NOT ") + "a pure imaginary number");

        System.out.println("Number 2 is: " + num2);
        System.out.println(num2 + " is " + (num2.isReal() ? "" : "NOT ") + "a pure real number");
        System.out.println(num2 + " is " + (num2.isImaginary() ? "" : "NOT ") + "a pure imaginary number");

        System.out.println(num1 + " is " + (num1.equals(num2) ? "" : "NOT ") + "equal to " + num2);
        System.out.println(num1 + " + " + num2 + " = " + num1.addNew(num2));
        System.out.println(num1 + " - " + num2 + " = " + num1.subtractNew(num2));
        System.out.println(num1 + " * " + num2 + " = " + num1.multiply(new MyComplex(num2.getReal(), num2.getImag())));
        System.out.println(num1 + " / " + num2 + " = " + num1.divide(new MyComplex(num2.getReal(), num2.getImag())));
        System.out.println("Conjugate of " + num1 + " is " + num1.conjugate());
    }
}
