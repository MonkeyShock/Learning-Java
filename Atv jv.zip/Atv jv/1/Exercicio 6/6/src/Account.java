public class Account {
    private String id;
    private String name;
    private int balance = 0;

    Account(String id, String name) {
        this.id = id;
        this.name = name;
    }

    Account(String id, String name, int balance) {
        this.balance = balance;
        this.id = id;
        this.name = name;
    }

    public String getID() {
        return id;
    }

    public int getBalance() {
        return balance;
    }

    public String getName() {
        return name;
    }

    public int credit(int balance) {
        this.balance = balance + this.balance;
        return this.balance;
    }

    public int debit(int balance) {
        if (balance > this.balance)
            System.out.println("Ammount Exceed");
        else
            this.balance = this.balance - balance;
        return this.balance;
    }

    public int transferTo(Account p, int Ammount) {
        if (Ammount > this.balance)
            System.out.println("Ammount Exceed");
        else {
            p.balance = p.balance + Ammount;
            this.balance = this.balance - Ammount;
        }
        return this.balance;
    }

    public String toString() {
        return "Account[id = " + this.id + ", name = " + this.name + ", balance =" + this.balance + "] ";
    }
}
