public class TestMyIntStack {
    public static void main(String[] args) {
        // Teste 1: Lançar IllegalStateException se a pilha estiver cheia
        try {
            MyIntStack stack1 = new MyIntStack(2);
            stack1.push1(1);
            stack1.push1(2);
            stack1.push1(3); // Deve lançar IllegalStateException
        } catch (IllegalStateException e) {
            System.out.println("Caught exception: " + e.getMessage());
        }

        // Teste 2: Retornar true ou false dependendo do sucesso da operação
        MyIntStack stack2 = new MyIntStack(2);
        System.out.println(stack2.push2(1)); // true
        System.out.println(stack2.push2(2)); // true
        System.out.println(stack2.push2(3)); // false (stack is full)

        // Teste 3: Aumentar a capacidade da pilha se estiver cheia
        MyIntStack stack3 = new MyIntStack(2);
        stack3.push3(1);
        stack3.push3(2);
        stack3.push3(3); // Deve aumentar a capacidade e adicionar o elemento
        System.out.println(stack3.pop()); // 3
        System.out.println(stack3.pop()); // 2
        System.out.println(stack3.pop()); // 1
    }
}
