public class MyIntStack {
    private int[] contents;
    private int tos; // Top of the stack

    // Construtores
    public MyIntStack(int capacity) {
        contents = new int[capacity];
        tos = -1;
    }

    // 1. Modificar `push` para lançar `IllegalStateException` se a pilha estiver
    // cheia
    public void push1(int element) {
        if (isFull()) {
            throw new IllegalStateException("Stack is full");
        }
        contents[++tos] = element;
    }

    // 2. Modificar `push` para retornar `true` se a operação for bem-sucedida, ou
    // `false` caso contrário
    public boolean push2(int element) {
        if (isFull()) {
            return false;
        }
        contents[++tos] = element;
        return true;
    }

    // 3. Modificar `push` para aumentar a capacidade realocando outro array, se a
    // pilha estiver cheia
    public void push3(int element) {
        if (isFull()) {
            // Duplicar a capacidade do array
            int[] newContents = new int[contents.length * 2];
            System.arraycopy(contents, 0, newContents, 0, contents.length);
            contents = newContents;
        }
        contents[++tos] = element;
    }

    public int pop() {
        return contents[tos--];
    }

    public int peek() {
        return contents[tos];
    }

    public boolean isEmpty() {
        return tos < 0;
    }

    public boolean isFull() {
        return tos == contents.length - 1;
    }
}
