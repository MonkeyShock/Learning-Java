public abstract class Usuarios {
    private String nome;
    private String email;
    private String id;

    public Usuarios(String nome, String email, String id) {
        this.nome = nome;
        this.email = email;
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getRegistro() {
        return id;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\nEmail: " + email + "\nID: " + id;
    }

    public abstract int getLimiteEmprestimo();
}
