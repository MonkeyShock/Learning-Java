public class Alunos extends Usuarios {
    private String curso;

    Alunos(String nome, String email, String id, String curso) {
        super(nome, email, id);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCurso: " + curso;
    }

    @Override
    public int getLimiteEmprestimo() {
        return 15;
    }
}
