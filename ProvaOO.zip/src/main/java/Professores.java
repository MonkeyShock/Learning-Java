public class Professores extends Usuarios {
    private String departamento;

    Professores(String nome, String email, String id, String departamento) {
        super(nome, email, id);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    @Override
    public String toString() {
        return super.toString() + "\nDepartamento: " + departamento;
    }

    @Override
    public int getLimiteEmprestimo() {
        return 90;
    }
}
