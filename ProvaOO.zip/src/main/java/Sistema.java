import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Sistema {
    private List<Usuarios> cadastrados;
    private List<Biblioteca> livros;
    private List<Emprestimo> emprestimos;

    public Sistema() {
        cadastrados = new ArrayList<Usuarios>();
        livros = new ArrayList<Biblioteca>();
        emprestimos = new ArrayList<Emprestimo>();

        
        livros.add(new Biblioteca("Python", 1));
        livros.add(new Biblioteca("Eletronica Digital", 2));
        livros.add(new Biblioteca("POO", 3));
        livros.add(new Biblioteca("Calculo I", 4));
        livros.add(new Biblioteca("Calculo II", 5));
        livros.add(new Biblioteca("Calculo III", 6));
        livros.add(new Biblioteca("Algebra Linear", 7));
        livros.add(new Biblioteca("Visao Computacional", 8));
        livros.add(new Biblioteca("Inteligencia Artificial", 9));
        livros.add(new Biblioteca("Codigo Limpo", 10));
    }

    public void cadastroUsuario(Usuarios usuario) {
        if (!verificarCadastro(usuario.getRegistro())) {
            cadastrados.add(usuario);
            System.out.println("\nUsuário cadastrado com sucesso!");
        } else {
            System.out.println("\nUsuário já cadastrado!");
        }
    }

    public void cadastroLivro(Biblioteca livro) {
        if (livros.contains(livro)) {
            System.out.println("\nLivro já cadastrado!");
        } else {
            livros.add(livro);
            System.out.println("\nLivro cadastrado com sucesso!");
        }
    }

    public void realizarEmprestimo(Usuarios usuario, Biblioteca livro) {
        if (!verificarCadastro(usuario.getRegistro())) {
            System.out.println("\nUsuário não cadastrado!");
            return;
        }

        if (!livros.contains(livro)) {
            System.out.println("\nLivro não cadastrado!");
            return;
        }

        if (livroJaEmprestado(livro)) {
            System.out.println("\nLivro já está emprestado!");
            return;
        }

        int prazoDevolucao = getPrazoDevolucao(usuario);

        LocalDate dataEmprestimo = LocalDate.now(); //Simular atrado .minusDays(30)
        LocalDate dataDevolucao = dataEmprestimo.plusDays(prazoDevolucao); // Prazo de devolução + 5 dias plusDays(prazoDevolucao + 5)

        Emprestimo novoEmprestimo = new Emprestimo(usuario, livro, dataEmprestimo, dataDevolucao);
        emprestimos.add(novoEmprestimo);

        System.out.println("\nEmpréstimo realizado com sucesso!");
        System.out.println("\nData de devolução: " + dataDevolucao);
    }

    public void exibirObrasEmAtraso() {
        LocalDate hoje = LocalDate.now();

        for (Emprestimo emprestimo : emprestimos) {
            if (emprestimo.getUsuario() instanceof Alunos) {
                LocalDate dataDevolucao = emprestimo.getDataDevolucao();
                if (dataDevolucao.isBefore(hoje)) {
                    System.out.println("Usuário: " + emprestimo.getUsuario().getRegistro() +
                            ", Obra: " + emprestimo.getLivro().getNome());
                }
            }
        }
    }

    private boolean verificarCadastro(String registro) {
        for (Usuarios u : cadastrados) {
            if (u.getRegistro().equals(registro)) {
                return true;
            }
        }
        return false;
    }

    private int getPrazoDevolucao(Usuarios usuario) {
        if (usuario instanceof Alunos) {
            return 15; 
        } else if (usuario instanceof Professores) {
            return 90; 
        } else if (usuario instanceof Funcionarios) {
            return 30; 
        }
        return 15; 
    }

    private boolean livroJaEmprestado(Biblioteca livro) {
        for (Emprestimo emprestimo : emprestimos) {
            if (emprestimo.getLivro().equals(livro)) {
                return true;
            }
        }
        return false;
    }

    
    public List<Usuarios> getUsuarios() {
        return cadastrados;
    }

   
    public List<Biblioteca> getLivros() {
        return livros;
    }
}
