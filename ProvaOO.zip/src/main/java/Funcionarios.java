public class Funcionarios extends Usuarios {
    private String cargo;

    Funcionarios(String nome, String email, String id, String cargo) {
        super(nome, email, id);
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCargo: " + cargo;
    }

    @Override
    public int getLimiteEmprestimo() {
        return 30;
    }
}
