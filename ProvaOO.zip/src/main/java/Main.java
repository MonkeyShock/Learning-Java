import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;
        while (continuar) {
            System.out.println("Escolha uma opção:\n");
            System.out.println("1. Cadastrar Professor");
            System.out.println("2. Cadastrar Funcionário");
            System.out.println("3. Cadastrar Aluno");
            System.out.println("4. Exibir todos os usuários cadastrados");
            System.out.println("5. Exibir Lista de Obras em Atraso");
            System.out.println("6. Realizar Empréstimo");
            System.out.println("7. Sair");
            int escolha = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            switch (escolha) {
                case 1:
                    System.out.println("\nDigite o nome:");
                    String nomeProf = scanner.nextLine();
                    System.out.println("Digite o email:");
                    String emailProf = scanner.nextLine();
                    System.out.println("Digite o ID:");
                    String idProf = scanner.nextLine();
                    System.out.println("Digite o departamento:");
                    String departamento = scanner.nextLine();
                    Professores professor = new Professores(nomeProf, emailProf, idProf, departamento);
                    sistema.cadastroUsuario(professor);
                    System.out.println("\nProfessor cadastrado:\n" + professor + "\n");
                    break;
                case 2:
                    System.out.println("\nDigite o nome:");
                    String nomeFunc = scanner.nextLine();
                    System.out.println("Digite o email:");
                    String emailFunc = scanner.nextLine();
                    System.out.println("Digite o ID:");
                    String idFunc = scanner.nextLine();
                    System.out.println("Digite o cargo:");
                    String cargo = scanner.nextLine();
                    Funcionarios funcionario = new Funcionarios(nomeFunc, emailFunc, idFunc, cargo);
                    sistema.cadastroUsuario(funcionario);
                    System.out.println("\nFuncionário cadastrado:\n" + funcionario + "\n");
                    break;
                case 3:
                    System.out.println("\nDigite o nome:");
                    String nomeAluno = scanner.nextLine();
                    System.out.println("Digite o email:");
                    String emailAluno = scanner.nextLine();
                    System.out.println("Digite o ID:");
                    String idAluno = scanner.nextLine();
                    System.out.println("Digite o curso:");
                    String curso = scanner.nextLine();
                    Alunos aluno = new Alunos(nomeAluno, emailAluno, idAluno, curso);
                    sistema.cadastroUsuario(aluno);
                    System.out.println("\nAluno cadastrado:\n" + aluno + "\n");
                    break;
                case 4:
                    List<Usuarios> usuariosCadastrados = sistema.getUsuarios();
                    if (usuariosCadastrados.isEmpty()) {
                        System.out.println("\nNenhum usuário cadastrado.\n");
                    } else {
                        System.out.println("\nUsuários cadastrados:\n");
                        for (Usuarios u : usuariosCadastrados) {
                            System.out.println(u);
                            System.out.println(); // Adiciona uma linha em branco após cada usuário
                        }
                        System.out.println();
                    }
                    break;
                case 5:
                    sistema.exibirObrasEmAtraso();
                    break;
                case 6:
                    System.out.println("\nDigite o ID do usuário para empréstimo:");
                    String idUsuario = scanner.nextLine();
                    Usuarios usuario = sistema.getUsuarios().stream()
                            .filter(u -> u.getRegistro().equals(idUsuario))
                            .findFirst()
                            .orElse(null);
                    if (usuario != null) {
                        List<Biblioteca> livrosDisponiveis = sistema.getLivros();
                        if (livrosDisponiveis.isEmpty()) {
                            System.out.println("\nNenhum livro disponível para empréstimo.\n");
                        } else {
                            System.out.println("\nLivros disponíveis para empréstimo:");
                            for (Biblioteca livro : livrosDisponiveis) {
                                System.out.println(livro.getCodigo() + ". " + livro.getNome());
                            }

                            System.out.println("\nDigite o código do livro para empréstimo:");
                            int codigoLivro = scanner.nextInt();
                            scanner.nextLine(); // Consumir a nova linha

                            Biblioteca livroSelecionado = livrosDisponiveis.stream()
                                    .filter(l -> l.getCodigo() == codigoLivro)
                                    .findFirst()
                                    .orElse(null);

                            if (livroSelecionado != null) {
                                sistema.realizarEmprestimo(usuario, livroSelecionado);
                            } else {
                                System.out.println("\nLivro não encontrado!\n");
                            }
                        }
                    } else {
                        System.out.println("\nUsuário não encontrado!\n");
                    }
                    break;
                case 7:
                    continuar = false;
                    break;
                default:
                    System.out.println("\nEscolha inválida.\n");
                    break;
            }
        }

        scanner.close();
    }
}
